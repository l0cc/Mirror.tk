namespace bigtutorial
{


	void help();
	void test();


}

void bigtutorial::help()
{

	float yourIQ = 00000001;
		yourIQ = 23658235;

		float killme = 6548632352;
		killme = 63285235;


		static bool smart = false;
		static bool IfYouCantTellImMakingFunOfTheIdiotsFromMyLastMirrorVideos = false;

		if (killme = 783295)
		{
			if (yourIQ = 0)
			{
				killme = 7328532;
				yourIQ = 00012;
				yourIQ = 68325623;
				smart = false;
			}
			else if (yourIQ = 82375)
			{
				yourIQ = 3628525;
				yourIQ = 823523;
				smart = true;

			}
		}
		else
		{

			yourIQ = 00001;
			killme = 999991124;

			IfYouCantTellImMakingFunOfTheIdiotsFromMyLastMirrorVideos = true;


		}



}


/*

YOOOO Thanks for downloading Mirror.tk V2! This open source version has fixed a lot of the complaints with Mirror.tk V1 and has a lot of upgraded stuff. Like the resolver and anti aims,
which i had to update and couldn't resist making a meme out of because penguware actually copied from Mirror but were too stupid to fix my FPS cap, since all their features are Mirror
features but the menu isn't. LMAO!


Also if you are that autistic, YES, THE .DLL IS INCLUDED WITHOUT NEEDING TO COMPILE!

~For the noobies amoung you, i have included little hints and notes to help you guys fix stuff, learn for yourselves and the YES and NO things when it comes to being a ProPenguPaster


MAKING IT UNDETECTED + JUNK CODE:

What is it?
- VAC is a signature detecting anti cheat, if the signature is different enough, this means that it will be undetected.You can download 
https://www.unknowncheats.me/forum/anti-cheat-bypass/167449-sigbench-test-binary-signature-scans.html to compare .dll signatures. If sig difference is more than 45%, have fun in match making.

How Do I Change Signatures?
- Add junk code mah nigga! Anything you do to the cheat changes junk code. From value differences to what is different inside of a code block or outright deleting blocks, everything changes the signature.
I included MANY examples of Junk Code throughout this source (in case you are a blind fucking bat lmao, one example is right above you), you gotta change numbers and add more lines, you also gotta
create a declaration depending on the name of the junk block. So if you have junk block named " junkcode1 " and you want to make one called " junkcode 2 ", do it, right click it, first option, "Add Declaration"
then click the X on the blue box and hit save. Even an autist like Pengu can do it, sooooo you got no excuse. You can also delete parts of the source, for example, you can delete something like
" DrawArmor ", just CTRL + F select the "Entire solution" option, then "Find All" and delete every mention of " Draw Armor ". Good luck have fun ya dumbo.

Too many errors! How Do I Compile?
- * facepalm * you fucking idiot, see those cute litte boxes up there that say DEBUG and x64 right under "debug" "Team" and "tools"? Yeah click those and select "Release" and "x86", then click debug,
go down to the very last option and set the build version to " v141 " like http://prntscr.com/gxnco6



RANDOM QUESTIONS

Why Are You Releasing This?
1- Because too many austists like to sell pastes and the pub available ones are almost always under average (aka total fucking trash, go uninstall), so, with this, if someone *cough Ju$tin* is going to
shamelessly paste shit and brag about how good it is, at least the 12 year old kids that buy it will at least have something DECENT.

2- People need a good base on which to build their cheats. I have spoonfed 500% more than most other people on UC combined, so there is literally NO EXCUSE for you saying stuff doesn't work because I MADE
SURE IT DOES. So, therefor, people can build their own cheats easily.


Why Do You Hate Penguware?
- discord spamming, brattish, cuntish, childish fags just pasting random shit from UnkownCheats and are actually saying they are better than other pastes or some p2c, shameless little cunts.
I kinda released this so people have something better to build off of.

Are You Gay?
- mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm idk






*/

