

#pragma once

#define AYYWARE_META_GAME "Counter-Strike: Global Offensive"
#define AYYWARE_META_CHEATVER "2.1"
#define AYYWARE_META_CHEATNAME "Mirror.tk V2 for Counter-Strike: Global Offensive"

void PrintMetaHeader();