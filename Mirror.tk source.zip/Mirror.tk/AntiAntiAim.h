
// Credits to Valve and Shad0w
#pragma once
void ApplyNetVarsHooks();
void RemoveNetVarsHooks();
