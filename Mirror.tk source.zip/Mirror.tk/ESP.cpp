

#include "ESP.h"
#include "Interfaces.h"
#include "RenderManager.h"
#include "Glowmanager.h"
DWORD GlowManager = *(DWORD*)(Utilities::Memory::FindPatternV2("client.dll", "0F 11 05 ?? ?? ?? ?? 83 C8 01 C7 05 ?? ?? ?? ?? 00 00 00 00") + 3);
IClientEntity *BombCarrier;
void CEsp::Init()
{
	BombCarrier = nullptr;
}

// Yeah dude we're defo gunna do some sick moves for the esp yeah
void CEsp::Move(CUserCmd *pCmd,bool &bSendPacket) 
{

}

// Main ESP Drawing loop
void CEsp::Draw()
{
	IClientEntity *pLocal = hackManager.pLocal();

	for (int i = 0; i < Interfaces::EntList->GetHighestEntityIndex(); i++)
	{
			IClientEntity *pEntity = Interfaces::EntList->GetClientEntity(i);
			player_info_t pinfo;

			if (pEntity &&  pEntity != pLocal && !pEntity->IsDormant())
			{
				if (Menu::Window.VisualsTab.OtherRadar.GetState())
				{
					DWORD m_bSpotted = NetVar.GetNetVar(0x839EB159);
					*(char*)((DWORD)(pEntity)+m_bSpotted) = 1;
				}

				if (Menu::Window.VisualsTab.FiltersPlayers.GetState() && Interfaces::Engine->GetPlayerInfo(i, &pinfo) && pEntity->IsAlive())
				{
					DrawPlayer(pEntity, pinfo);
				}

				ClientClass* cClass = (ClientClass*)pEntity->GetClientClass();

				if (Menu::Window.VisualsTab.FiltersWeapons.GetState() && cClass->m_ClassID != (int)CSGOClassID::CBaseWeaponWorldModel && ((strstr(cClass->m_pNetworkName, "Weapon") || cClass->m_ClassID == (int)CSGOClassID::CDEagle || cClass->m_ClassID == (int)CSGOClassID::CAK47)))
				{
					DrawDrop(pEntity, cClass);
				}

				if (Menu::Window.VisualsTab.FiltersC4.GetState())
				{
					if (cClass->m_ClassID == (int)CSGOClassID::CPlantedC4)
						DrawBombPlanted(pEntity, cClass);

					if (cClass->m_ClassID == (int)CSGOClassID::CC4)
						DrawBomb(pEntity, cClass);
				}

				if (Menu::Window.VisualsTab.FiltersChickens.GetState())
				{
					if (cClass->m_ClassID == (int)CSGOClassID::CChicken)
						DrawChicken(pEntity, cClass);
				}
			}
		}

		if (Menu::Window.MiscTab.OtherSpectators.GetState())
		{
			SpecList();
		}

}

void CEsp::SpecList()
{
	IClientEntity *pLocal = hackManager.pLocal();

	RECT scrn = Render::GetViewport();
	int ayy = 0;

	// Loop through all active entitys
	for (int i = 0; i < Interfaces::EntList->GetHighestEntityIndex(); i++)
	{
		// Get the entity
		IClientEntity *pEntity = Interfaces::EntList->GetClientEntity(i);
		player_info_t pinfo;

		// The entity isn't some laggy peice of shit or something
		if (pEntity &&  pEntity != pLocal)
		{
			if (Interfaces::Engine->GetPlayerInfo(i, &pinfo) && !pEntity->IsAlive() && !pEntity->IsDormant())
			{
				HANDLE obs = pEntity->GetObserverTargetHandle();

				if (obs)
				{
					IClientEntity *pTarget = Interfaces::EntList->GetClientEntityFromHandle(obs);
					player_info_t pinfo2;
					if (pTarget)
					{
						if (Interfaces::Engine->GetPlayerInfo(pTarget->GetIndex(), &pinfo2))
						{
							char buf[255]; sprintf_s(buf, "%s: %s", pinfo.name, pinfo2.name);
							RECT TextSize = Render::GetTextSize(Render::Fonts::ESP, buf);
							Render::Clear(scrn.right - 255, (scrn.bottom / 2) + (16 * ayy), 260, 16, Color(0, 0, 0, 0));
							Render::Text(scrn.right - TextSize.right - 4, (scrn.bottom / 2) + (10 /* i changed from 16 to 10 */ * ayy), pTarget->GetIndex() == pLocal->GetIndex() ? Color(240, 0, 190, 200) : Color(255, 255, 255, 200), Render::Fonts::othershit, buf);
							ayy++;
						}
					}
				}
			}
		}
	}

	Render::Outline(scrn.right - 261, (scrn.bottom / 2) - 1, 262, (16 * ayy) + 2, Color(23, 23, 23, 0));
	Render::Outline(scrn.right - 260, (scrn.bottom / 2), 260, (16 * ayy), Color(90, 90, 90, 0));
}

//  Yeah m8
void CEsp::DrawPlayer(IClientEntity* pEntity, player_info_t pinfo)
{
	ESPBox Box;
	Color Color;

	// Show own team false? well gtfo teammate lol
	if (Menu::Window.VisualsTab.FiltersEnemiesOnly.GetState() && (pEntity->GetTeamNum() == hackManager.pLocal()->GetTeamNum()))
		return;

	if (GetBox(pEntity, Box))
	{
		Color = GetPlayerColor(pEntity);

		if (Menu::Window.VisualsTab.OptionsBox.GetIndex())
			DrawBox(Box, Color);

		if (Menu::Window.VisualsTab.OptionsName.GetState())
			DrawName(pinfo, Box);

		if (Menu::Window.VisualsTab.OptionsHealth.GetState())
			DrawHealth(Box, pEntity);

		if (Menu::Window.VisualsTab.OptionsInfo.GetState() || Menu::Window.VisualsTab.OptionsWeapon.GetState())
			DrawInfo(pEntity, Box);

		if (Menu::Window.VisualsTab.OptionsAimSpot.GetState())
			DrawCross(pEntity);

		if (Menu::Window.VisualsTab.OptionsArmor.GetState())
			Armor(Box, pEntity);

		if (Menu::Window.VisualsTab.OptionsSkeleton.GetState())
			DrawSkeleton(pEntity);

		if (Menu::Window.VisualsTab.OptionsGlow.GetState())
			DrawGlow();

		if (Menu::Window.VisualsTab.OptionsBarrels.GetState())
			Barrel(Box, Color, pEntity);
	}
}


// Gets the 2D bounding box for the entity
// Returns false on failure nigga don't fail me
bool CEsp::GetBox(IClientEntity* pEntity, CEsp::ESPBox &result)
{
	// Variables
	Vector  vOrigin, min, max, sMin, sMax, sOrigin,
		flb, brt, blb, frt, frb, brb, blt, flt;
	float left, top, right, bottom;

	// Get the locations
	vOrigin = pEntity->GetOrigin();
	min = pEntity->collisionProperty()->GetMins() + vOrigin;
	max = pEntity->collisionProperty()->GetMaxs() + vOrigin;

	// Points of a 3d bounding box
	Vector points[] = { Vector(min.x, min.y, min.z),
		Vector(min.x, max.y, min.z),
		Vector(max.x, max.y, min.z),
		Vector(max.x, min.y, min.z),
		Vector(max.x, max.y, max.z),
		Vector(min.x, max.y, max.z),
		Vector(min.x, min.y, max.z),
		Vector(max.x, min.y, max.z) };

	// Get screen positions
	if (!Render::WorldToScreen(points[3], flb) || !Render::WorldToScreen(points[5], brt)
		|| !Render::WorldToScreen(points[0], blb) || !Render::WorldToScreen(points[4], frt)
		|| !Render::WorldToScreen(points[2], frb) || !Render::WorldToScreen(points[1], brb)
		|| !Render::WorldToScreen(points[6], blt) || !Render::WorldToScreen(points[7], flt))
		return false;

	// Put them in an array (maybe start them off in one later for speed?)
	Vector arr[] = { flb, brt, blb, frt, frb, brb, blt, flt };

	// Init this shit
	left = flb.x;
	top = flb.y;
	right = flb.x;
	bottom = flb.y;

	// Find the bounding corners for our box
	for (int i = 1; i < 8; i++)
	{
		if (left > arr[i].x)
			left = arr[i].x;
		if (bottom < arr[i].y)
			bottom = arr[i].y;
		if (right < arr[i].x)
			right = arr[i].x;
		if (top > arr[i].y)
			top = arr[i].y;
	}

	// Width / height
	result.x = left;
	result.y = top;
	result.w = right - left;
	result.h = bottom - top;

	return true;
}

/*

void CEsp::Junk2() // Junkcode. You now have no reason to say you don't know how to add junk code.
{
	float pJunkcode = 511346458563;
	pJunkcode = 9783257111189242;
	pJunkcode = 2395862375;

	float youtube = 372956325;
	youtube = 9235378525;

	if (pJunkcode = 1712359625)
		pJunkcode = 18343221199625;                    // YOOOOOO    CHANGE ALL THESE NUMBERS
	pJunkcode = 78623475;
	pJunkcode = 1111745646898911;
	if (pJunkcode = 349855890534);
	pJunkcode = 2304892193748943;
	pJunkcode = 439085600453;
	if (pJunkcode = 1713894266345)                 // ALSO ADD A FEW MORE LINES
		pJunkcode = 1817542425;
	pJunkcode = 173275111895;
	pJunkcode = 4357819553434;
	if (pJunkcode = 3492756490534);
	pJunkcode = 9213741128943;
	pJunkcode = 4390751394634635113;
	if (pJunkcode = 173218925342425)
		pJunkcode = 183543254113425;
	pJunkcode = 1732423198465;
	pJunkcode = 432352265416534;
	if (pJunkcode = 349785655474);
	pJunkcode = 233743333343346;
	pJunkcode = 43904360453;

	if (pJunkcode = 87235)
	{
		pJunkcode = 672385235;
		pJunkcode = 901242352523;
		if (youtube = 2387523652)
		{
			pJunkcode = 23785235923;
			youtube = 37259235235;
			youtube = 827358235;
			pJunkcode = 9000023525;
			pJunkcode = 2359623785235;
		}
		else if (youtube = 872356325235)
		{
			youtube = 6812423525;
			youtube = 32856235;
			pJunkcode = 63285235325;
			youtube = 7372895238523;
			youtube = 73928658236572;
			pJunkcode = 3295237852352;
		}

	}
}

*/

void CEsp::meme()
{

	float die = 237562395;
	die = 328652385;

	float mirror =  237586923865;
	mirror = 72368923565;

	if (mirror = 385325)
		mirror = 237596325;

}
void CEsp::DrawGlow()
{
	CGlowObjectManager* GlowObjectManager = (CGlowObjectManager*)GlowManager;

	for (int i = 0; i < GlowObjectManager->size; ++i)
	{
		CGlowObjectManager::GlowObjectDefinition_t* glowEntity = &GlowObjectManager->m_GlowObjectDefinitions[i];
		IClientEntity* Entity = glowEntity->getEntity();

		if (glowEntity->IsEmpty() || !Entity)
			continue;

		switch (Entity->GetClientClass()->m_ClassID)
		{
		case 35:
			if (Menu::Window.VisualsTab.OptionsGlow.GetState())
			{
				if (!Menu::Window.VisualsTab.FiltersPlayers.GetState() && !(Entity->GetTeamNum() == hackManager.pLocal()->GetTeamNum()))
					break;
				if (Menu::Window.VisualsTab.FiltersEnemiesOnly.GetState() && (Entity->GetTeamNum() == hackManager.pLocal()->GetTeamNum()))
					break;

				if (GameUtils::IsVisible(hackManager.pLocal(), Entity, 0))
				{
					glowEntity->set((Entity->GetTeamNum() == hackManager.pLocal()->GetTeamNum()) ? Color(0, 120, 255, 150) : Color(0, 110, 255, 170));
				}

				else
				{
					glowEntity->set((Entity->GetTeamNum() == hackManager.pLocal()->GetTeamNum()) ? Color(255, 255, 0, 150) : Color(255, 255, 0, 170));
				}
			}
		}
	}
}

void CEsp::Barrel(CEsp::ESPBox size, Color color, IClientEntity* pEntity)
{
	Vector src3D, src;
	src3D = pEntity->GetOrigin() - Vector(0, 0, 0);

	if (!Render::WorldToScreen(src3D, src))
		return;

	int ScreenWidth, ScreenHeight;
	Interfaces::Engine->GetScreenSize(ScreenWidth, ScreenHeight);

	int x = (int)(ScreenWidth * 0.5f);
	int y = 0;


	y = ScreenHeight;

	Render::Line((int)(src.x), (int)(src.y), x, y, Color(230, 0, 170, 255));
}


void CEsp::Junk4()    //         YOU HAVE TO CHANGE NUMBERS AND ADD MORE LINES

{
	float pJunkcode = 51178011453;
	pJunkcode = 134453242;
	if (pJunkcode = 17135245325)
		pJunkcode = 157611425;
	pJunkcode = 856525;
	pJunkcode = 1118997897811;
	if (pJunkcode = 452739789734);
	pJunkcode = 267906798943;
	pJunkcode = 439905548967953;
	if (pJunkcode = 17859425)
		pJunkcode = 181555912425;
	pJunkcode = 173255595;
	pJunkcode = 43578195346534;
	if (pJunkcode = 343555554);
	pJunkcode = 230489251374118943;
	pJunkcode = 43907513945113;
	if (pJunkcode = 1732189342425)
		pJunkcode = 183413254113425;
	pJunkcode = 1732423198465;
	pJunkcode = 435789513416534;
	if (pJunkcode = 349345574);
	pJunkcode = 230489214189143346;
	pJunkcode = 4390437910453;
	float LGGrxnFfzi = 2978678590020;
	LGGrxnFfzi = 90775251329102; 
	if (LGGrxnFfzi = 79039549484475) 
		LGGrxnFfzi = 99569238257106; 
	LGGrxnFfzi = 72530676294199; 
	LGGrxnFfzi = 62941997253067;
	if (LGGrxnFfzi = 1642709956923)
		LGGrxnFfzi = 94844755895034; 
	LGGrxnFfzi = 87283343948475;
	if (LGGrxnFfzi = 90540445814364)
		LGGrxnFfzi = 94844755895034; 
	LGGrxnFfzi = 87283343948475;
	if (LGGrxnFfzi = 90540445814364)
		LGGrxnFfzi = 94844755895034; 
	LGGrxnFfzi = 87283343948475;
	if (LGGrxnFfzi = 90540445814364)
		LGGrxnFfzi = 94844755895034;
	LGGrxnFfzi = 87283343948475;
	if (LGGrxnFfzi = 90540445814364)
		LGGrxnFfzi = 94844755895034; 
	LGGrxnFfzi = 87283343948475; 
	LGGrxnFfzi = 32938883141831;
	float tLndPNdtwr = 84389253817008; 
	tLndPNdtwr = 69382855689882;
	if (tLndPNdtwr = 62198694190957) 
		tLndPNdtwr = 13171712273810;
	tLndPNdtwr = 66720781287899; 
	tLndPNdtwr = 12878996672078;
	if (tLndPNdtwr = 62680231317171)
		tLndPNdtwr = 41909571580534; 
	tLndPNdtwr = 68188391287070;
	if (tLndPNdtwr = 9579392093646)
		tLndPNdtwr = 41909571580534; 
	tLndPNdtwr = 68188391287070;
	if (tLndPNdtwr = 9579392093646)
		tLndPNdtwr = 41909571580534; 
	tLndPNdtwr = 68188391287070;
	if (tLndPNdtwr = 9579392093646)
		tLndPNdtwr = 41909571580534; 
	tLndPNdtwr = 68188391287070;
	if (tLndPNdtwr = 9579392093646)
		tLndPNdtwr = 41909571580534; 
	tLndPNdtwr = 68188391287070; 
	tLndPNdtwr = 2612746667163;
	float NeErHGryYq = 10795069122931; 
	NeErHGryYq = 70914965053646; 
	if (NeErHGryYq = 2853822220011) 
		NeErHGryYq = 8643882186244; 
	NeErHGryYq = 80061521093048; 
	NeErHGryYq = 10930488006152;
	if (NeErHGryYq = 92219908643882)
		NeErHGryYq = 2220011853385; 
	NeErHGryYq = 15344902431864;
	if (NeErHGryYq = 3983138898258)
		NeErHGryYq = 2220011853385; 
	NeErHGryYq = 15344902431864;
	if (NeErHGryYq = 3983138898258)
		NeErHGryYq = 2220011853385; 
	NeErHGryYq = 15344902431864;
	if (NeErHGryYq = 3983138898258)
		NeErHGryYq = 2220011853385; 
	NeErHGryYq = 15344902431864; 
	NeErHGryYq = 92291349083648;
	float ygpoTKFpau = 4602847016106;
	ygpoTKFpau = 35182541943666; 
	if (ygpoTKFpau = 60478344944090) 
		ygpoTKFpau = 40797729687967; 
	ygpoTKFpau = 2177702650335; 
	ygpoTKFpau = 2650335217770;
	if (ygpoTKFpau = 73233664079772)
		ygpoTKFpau = 49440909067056; 
	ygpoTKFpau = 65106185304992;
	if (ygpoTKFpau = 71243856433662)
		ygpoTKFpau = 49440909067056; 
	ygpoTKFpau = 65106185304992;
	if (ygpoTKFpau = 71243856433662)
		ygpoTKFpau = 49440909067056; 
	ygpoTKFpau = 65106185304992;
	if (ygpoTKFpau = 71243856433662)
		ygpoTKFpau = 49440909067056; 
	ygpoTKFpau = 65106185304992;
	if (ygpoTKFpau = 71243856433662)
		ygpoTKFpau = 49440909067056; 
	ygpoTKFpau = 65106185304992; 
	ygpoTKFpau = 87714605684943;

};


// Get an entities color depending on team and vis ect
Color CEsp::GetPlayerColor(IClientEntity* pEntity)
{
	int TeamNum = pEntity->GetTeamNum();
	bool IsVis = GameUtils::IsVisible(hackManager.pLocal(), pEntity, (int)CSGOHitboxID::Head);

	Color color;

	if (TeamNum == TEAM_CS_T)
	{
		if (IsVis)
			color = Color(235, 200, 0, 255);
		else
			color = Color(235, 50, 0, 255);
	}
	else
	{
		if (IsVis)
			color = Color(210, 120, 26, 255);
		else
			color = Color(15, 110, 220, 255);
	}


	return color;
}

// 2D  Esp box
void CEsp::DrawBox(CEsp::ESPBox size, Color color)
{
	{
		{
			int VertLine;
			int HorzLine;
			// Corner Box
			//bool IsVis = GameUtils::IsVisible(hackManager.pLocal(), pEntity, (int)CSGOHitboxID::Chest);  da dream
			int xd = Menu::Window.VisualsTab.OptionsBox.GetIndex();
			if (Menu::Window.VisualsTab.OptionsBox.GetIndex() == 1)
			{
				// Corner Box
				int VertLine = (((float)size.w) * (0.30f));
				int HorzLine = (((float)size.h) * (0.30f));

				Render::Clear(size.x, size.y - 1, VertLine, 1, Color(10, 10, 10, 240));
				Render::Clear(size.x + size.w - VertLine, size.y - 1, VertLine, 1, Color(10, 10, 10, 240));
				Render::Clear(size.x, size.y + size.h - 1, VertLine, 1, Color(10, 10, 10, 240));
				Render::Clear(size.x + size.w - VertLine, size.y + size.h - 1, VertLine, 1, Color(10, 10, 10, 240));

				Render::Clear(size.x - 1, size.y, 1, HorzLine, Color(10, 10, 10, 240));
				Render::Clear(size.x - 1, size.y + size.h - HorzLine, 1, HorzLine, Color(10, 10, 10, 240));
				Render::Clear(size.x + size.w - 1, size.y, 1, HorzLine, Color(10, 10, 10, 240));
				Render::Clear(size.x + size.w - 1, size.y + size.h - HorzLine, 1, HorzLine, Color(10, 10, 10, 240));

				Render::Clear(size.x, size.y, VertLine, 1, color);
				Render::Clear(size.x + size.w - VertLine, size.y, VertLine, 1, color);
				Render::Clear(size.x, size.y + size.h, VertLine, 1, color);
				Render::Clear(size.x + size.w - VertLine, size.y + size.h, VertLine, 1, color);

				Render::Clear(size.x, size.y, 1, HorzLine, color);
				Render::Clear(size.x, size.y + size.h - HorzLine, 1, HorzLine, color);
				Render::Clear(size.x + size.w, size.y, 1, HorzLine, color);
				Render::Clear(size.x + size.w, size.y + size.h - HorzLine, 1, HorzLine, color);
			} 

		if (Menu::Window.VisualsTab.OptionsBox.GetIndex() == 2)
			{
				{
					Render::Outline(size.x, size.y, size.w, size.h, color);
					Render::Outline(size.x - 1, size.y - 1, size.w + 2, size.h + 2, Color(10, 10, 10, 240));
					Render::Outline(size.x + 1, size.y + 1, size.w - 2, size.h - 2, Color(10, 10, 10, 240));
					Interfaces::Surface->DrawSetColor(80, 240, 190, 240);
				}

			}          

		}
	}
}


// Unicode Conversions
static wchar_t* CharToWideChar(const char* text)
{
	size_t size = strlen(text) + 1;
	wchar_t* wa = new wchar_t[size];
	mbstowcs_s(NULL, wa, size/4, text, size);
	return wa;
}

// Player name
void CEsp::DrawName(player_info_t pinfo, CEsp::ESPBox size)
{
	RECT nameSize = Render::GetTextSize(Render::Fonts::ESP, pinfo.name);
	Render::Text(size.x + (size.w / 2) - (nameSize.right / 2), size.y - 16,
		Color(255, 255, 255, 255), Render::Fonts::ESP, pinfo.name);
}

void CEsp::Armor(ESPBox box, IClientEntity* pEntity)
{

	float armor = pEntity->ArmorValue();

	if (armor > 100)
		armor = 100;

	Interfaces::Surface->DrawSetColor(0, 0, 0, 150);
	if (Menu::Window.VisualsTab.OptionsArmor.GetState())
	{
		int height = armor * box.h / 100;

		Interfaces::Surface->DrawOutlinedRect(box.x + box.w + 1, box.y - 1, box.x + box.w + 5, box.y + box.h + 1);



		if (armor > 0) 
		{
			Interfaces::Surface->DrawSetColor(80, 240, 190, 255);
			Interfaces::Surface->DrawFilledRect(box.x + box.w + 2,
				box.y + box.h - height,
				box.x + box.w + 4,
				box.y + box.h);
		}
	}
}

	/*
		ESPBox ArmorBar = size;
	if (Menu::Window.VisualsTab.OptionsArmur.GetState() == 1)
		ArmorBar.y += (ArmorBar.h + 6);
	else
		ArmorBar.y += (ArmorBar.h + 0);

	ArmorBar.h = 4;

	float ArmorValue = pEntity->ArmorValue();
	float ArmorPerc = ArmorValue / 100.f;
	float Width = (size.w * ArmorPerc);
	ArmorBar.w = Width;

	//  Main Bar  //
	Vertex_t Verts[4];
	Verts[0].Init(Vector2D(ArmorBar.x, ArmorBar.y));
	Verts[1].Init(Vector2D(ArmorBar.x + size.w, ArmorBar.y));
	Verts[2].Init(Vector2D(ArmorBar.x + size.w, ArmorBar.y + 5));
	Verts[3].Init(Vector2D(ArmorBar.x, ArmorBar.y + 5));

	Render::PolygonOutline(4, Verts, Color(0, 0, 0, 255), Color(0, 0, 0, 255));

	Vertex_t Verts2[4];
	Verts2[0].Init(Vector2D(ArmorBar.x + 1, ArmorBar.y + 1));
	Verts2[1].Init(Vector2D(ArmorBar.x + ArmorBar.w, ArmorBar.y + 1));
	Verts2[2].Init(Vector2D(ArmorBar.x + ArmorBar.w, ArmorBar.y + 5));
	Verts2[3].Init(Vector2D(ArmorBar.x, ArmorBar.y + 5));

	Color c = Color(0, 205, 247, 255);
	Render::Polygon(4, Verts2, c);

	Verts2[0].Init(Vector2D(ArmorBar.x + 1, ArmorBar.y + 1));
	Verts2[1].Init(Vector2D(ArmorBar.x + ArmorBar.w, ArmorBar.y + 1));
	Verts2[2].Init(Vector2D(ArmorBar.x + ArmorBar.w, ArmorBar.y + 2));
	Verts2[3].Init(Vector2D(ArmorBar.x, ArmorBar.y + 2));

	Render::Polygon(4, Verts2, Color(200, 0, 200, 255));
	*/


// Draw a health bar. For Tf2 when a bar is bigger than max health a second bar is displayed
void CEsp::DrawHealth(ESPBox box, IClientEntity* pEntity)
{


	float health = pEntity->GetHealth();

	if (health > 100)
		health = 100;

	int colors[2] = { 255 - (health * 2.55), health * 2.55 };

	Interfaces::Surface->DrawSetColor(0, 10, 50, 200);
	if (Menu::Window.VisualsTab.OptionsHealth.GetState())
	{
		Interfaces::Surface->DrawOutlinedRect(box.x - 5, box.y - 1, box.x - 1, box.y + box.h + 1);

		int height = health * box.h / 100;

		if (health > 0)
		{
			Interfaces::Surface->DrawSetColor(colors[0], colors[1], 0, 255);
			Interfaces::Surface->DrawFilledRect(box.x - 4,
				box.y + box.h - height,
				box.x - 2,
				box.y + box.h);
		}
	
	}
}
	


std::string CleanItemName(std::string name)
{
	std::string Name = name;
	// Tidy up the weapon Name
	if (Name[0] == 'C')
		Name.erase(Name.begin());

	// Remove the word Weapon
	auto startOfWeap = Name.find("Weapon");
	if (startOfWeap != std::string::npos)
		Name.erase(Name.begin() + startOfWeap, Name.begin() + startOfWeap + 6);

	return Name;
}

// Anything else: weapons, class state? idk
void CEsp::DrawInfo(IClientEntity* pEntity, CEsp::ESPBox size)
{
	std::vector<std::string> Info;

	// Player Weapon ESP
	IClientEntity* pWeapon = Interfaces::EntList->GetClientEntityFromHandle((HANDLE)pEntity->GetActiveWeaponHandle());
	if (Menu::Window.VisualsTab.OptionsWeapon.GetState() && pWeapon)
	{
		ClientClass* cClass = (ClientClass*)pWeapon->GetClientClass();
		if (cClass)
		{
			// Draw it
			Info.push_back(CleanItemName(cClass->m_pNetworkName));
		}
	}

	if (Menu::Window.VisualsTab.OptionsInfo.GetState() && pEntity == BombCarrier)
	{
		Info.push_back("Bomb Carrier");
	}

	static RECT Size = Render::GetTextSize(Render::Fonts::Menu, "Text");
	int i = 0;
	for (auto Text : Info)
	{
		Render::Text(size.x + size.w + 3, size.y + (i*(Size.bottom + 2)), Color(255, 255, 255, 255), Render::Fonts::Menu, Text.c_str());
		i++;
	}
}


// Little cross on their heads
void CEsp::DrawCross(IClientEntity* pEntity)
{
	Vector cross = pEntity->GetHeadPos(), screen;
	static int Scale = 2;
	if (Render::WorldToScreen(cross, screen))
	{
		Render::Clear(screen.x - Scale, screen.y - (Scale * 2), (Scale * 2), (Scale * 4), Color(20, 20, 20, 160));
		Render::Clear(screen.x - (Scale * 2), screen.y - Scale, (Scale * 4), (Scale * 2), Color(20, 20, 20, 160));
		Render::Clear(screen.x - Scale - 1, screen.y - (Scale * 2) - 1, (Scale * 2) - 2, (Scale * 4) - 2, Color(250, 250, 250, 160));
		Render::Clear(screen.x - (Scale * 2) - 1, screen.y - Scale - 1, (Scale * 4) - 2, (Scale * 2) - 2, Color(250, 250, 250, 160));
	}
}


void CEsp::GrenadeTrace()
{
	if (Menu::Window.VisualsTab.GrenadeTrace.GetState())
	{
		auto granade = Interfaces::CVar->FindVar("sv_grenade_trajectory");
		auto granadespoof = new SpoofedConvar(granade);
		granadespoof->SetInt(1);
	}
}


// Draws a dropped CS:GO Item
void CEsp::DrawDrop(IClientEntity* pEntity, ClientClass* cClass)
{
	Vector Box;
	CBaseCombatWeapon* Weapon = (CBaseCombatWeapon*)pEntity;
	IClientEntity* plr = Interfaces::EntList->GetClientEntityFromHandle((HANDLE)Weapon->GetOwnerHandle());
	if (!plr && Render::WorldToScreen(Weapon->GetOrigin(), Box))
	{
		if (Menu::Window.VisualsTab.OptionsBox.GetIndex())
		{
			Render::Outline(Box.x - 2, Box.y - 2, 4, 4, Color(255, 255, 255, 255));
			Render::Outline(Box.x - 3, Box.y - 3, 6, 6, Color(10, 10, 10, 150));
		}

		if (Menu::Window.VisualsTab.OptionsInfo.GetState())
		{
			std::string ItemName = CleanItemName(cClass->m_pNetworkName);
			RECT TextSize = Render::GetTextSize(Render::Fonts::ESP, ItemName.c_str());
			Render::Text(Box.x - (TextSize.right / 2), Box.y - 16, Color(255, 255, 255, 255), Render::Fonts::ESP, ItemName.c_str());
		}
	}
}

// Draws a chicken
void CEsp::DrawChicken(IClientEntity* pEntity, ClientClass* cClass)
{
	ESPBox Box;

	if (GetBox(pEntity, Box))
	{
		player_info_t pinfo; strcpy_s(pinfo.name, "Chicken :)");
		if (Menu::Window.VisualsTab.OptionsBox.GetIndex())
			DrawBox(Box, Color(255,255,255,255));

		if (Menu::Window.VisualsTab.OptionsName.GetState())
			DrawName(pinfo, Box);
	}
}

// Draw the planted bomb and timer
void CEsp::DrawBombPlanted(IClientEntity* pEntity, ClientClass* cClass) 
{
	BombCarrier = nullptr;

	Vector vOrig; Vector vScreen;
	vOrig = pEntity->GetOrigin();
	CCSBomb* Bomb = (CCSBomb*)pEntity;

	if (Render::WorldToScreen(vOrig, vScreen))
	{
		float flBlow = Bomb->GetC4BlowTime();
		float TimeRemaining = flBlow - (Interfaces::Globals->interval_per_tick * hackManager.pLocal()->GetTickBase());
		char buffer[64];
		sprintf_s(buffer, "Planted C4: %.1f", TimeRemaining);
		if (TimeRemaining >= 0.0f)
			Render::Text(vScreen.x, vScreen.y, Color(255, 15, 25, 255), Render::Fonts::Menu, buffer);
	}
}

void CEsp::DrawBomb(IClientEntity* pEntity, ClientClass* cClass)
{
	float nigger = 23856;
	nigger = 8912649122345;

	BombCarrier = nullptr;
	CBaseCombatWeapon *BombWeapon = (CBaseCombatWeapon *)pEntity;
	Vector vOrig; Vector vScreen;
	vOrig = pEntity->GetOrigin();
	bool adopted = true;
	HANDLE parent = BombWeapon->GetOwnerHandle();
	if (parent || (vOrig.x == 0 && vOrig.y == 0 && vOrig.z == 0))
	{
		IClientEntity* pParentEnt = (Interfaces::EntList->GetClientEntityFromHandle(parent));
		if (pParentEnt && pParentEnt->IsAlive())
		{
			BombCarrier = pParentEnt;
			adopted = false;
		}
	}

	if (adopted)
	{
		if (Render::WorldToScreen(vOrig, vScreen))
		{
			Render::Text(vScreen.x, vScreen.y, Color(208, 20, 25, 255), Render::Fonts::Menu, "C4");
		}
	}
}

void DrawBoneArray(int* boneNumbers, int amount, IClientEntity* pEntity, Color color)
{
	Vector LastBoneScreen;
	for (int i = 0; i < amount; i++)
	{
		Vector Bone = pEntity->GetBonePos(boneNumbers[i]);
		Vector BoneScreen;

		if (Render::WorldToScreen(Bone, BoneScreen))
		{
			if (i>0)
			{
				Render::Line(LastBoneScreen.x, LastBoneScreen.y, BoneScreen.x, BoneScreen.y, color);
			}
		}
		LastBoneScreen = BoneScreen;
	}
}

void DrawBoneTest(IClientEntity *pEntity)
{
	for (int i = 0; i < 127; i++)
	{
		Vector BoneLoc = pEntity->GetBonePos(i);
		Vector BoneScreen;
		if (Render::WorldToScreen(BoneLoc, BoneScreen))
		{
			char buf[10];
			_itoa_s(i, buf, 10);
			Render::Text(BoneScreen.x, BoneScreen.y, Color(255, 255, 255, 180), Render::Fonts::ESP, buf);
		}
	}
}



void CEsp::Junk() // Junkcode. You now have no reason to say you don't know how to add junk code.
{
	float pJunkcode = 511346458563;
	pJunkcode = 9783257111189242;
	pJunkcode = 2395862375;

	float youtube = 372956325;
	youtube = 9235378525;

	if (pJunkcode = 17123523132425)
		pJunkcode = 1832111199679425;
	pJunkcode = 1732000423230425;
	pJunkcode = 1111745646898911;
	if (pJunkcode = 349855890534);
	pJunkcode = 2304892193748943;
	pJunkcode = 439085600453;
	if (pJunkcode = 1713894266345)
		pJunkcode = 1817542425;
	pJunkcode = 173275111895;
	pJunkcode = 4357819553434;
	if (pJunkcode = 3492756490534);
	pJunkcode = 9213741128943;
	pJunkcode = 4390751394634635113;
	if (pJunkcode = 173218925342425)
		pJunkcode = 183543254113425;
	pJunkcode = 1732423198465;
	pJunkcode = 432352265416534;
	if (pJunkcode = 349785655474);
	pJunkcode = 233743333343346;
	pJunkcode = 43904360453;

	if (pJunkcode = 87235)
	{
		pJunkcode = 672385235;
		pJunkcode = 901242352523;
		if (youtube = 2387523652)
		{
			pJunkcode = 23785235923;
			youtube = 37259235235;
			youtube = 827358235;
			pJunkcode = 9000023525;
			pJunkcode = 2359623785235;
		}
		else if (youtube = 872356325235)
		{
			youtube = 6812423525;
			youtube = 32856235;
			pJunkcode = 63285235325;
			youtube = 7372895238523;
			youtube = 73928658236572;
			pJunkcode = 3295237852352;
		}

	}
}


void CEsp::DrawSkeleton(IClientEntity* pEntity)
{
	studiohdr_t* pStudioHdr = Interfaces::ModelInfo->GetStudiomodel(pEntity->GetModel());

	if (!pStudioHdr)
		return;

	Vector vParent, vChild, sParent, sChild;

	for (int j = 0; j < pStudioHdr->numbones; j++)
	{
		mstudiobone_t* pBone = pStudioHdr->GetBone(j);

		if (pBone && (pBone->flags & BONE_USED_BY_HITBOX) && (pBone->parent != -1))
		{
			vChild = pEntity->GetBonePos(j);
			vParent = pEntity->GetBonePos(pBone->parent);

			if (Render::WorldToScreen(vParent, sParent) && Render::WorldToScreen(vChild, sChild))
			{
				Render::Line(sParent[0], sParent[1], sChild[0], sChild[1], Color(250, 250, 250, 255));
			}
		}
	}
}