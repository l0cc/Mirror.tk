/*
Syn's AyyWare Framework 2015
*/

#pragma once

#include "Interfaces.h"
#include "Utilities.h"

namespace Dump
{
	void DumpClassIds();
};